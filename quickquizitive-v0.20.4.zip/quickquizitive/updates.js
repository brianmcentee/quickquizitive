const QQUpdates = (() => {
  const newer = (candidate,current) => {
    if (!/^\d+\.\d+\.\d+$/.test(candidate)) return false;
    const a=candidate.split('.').map(Number),b=current.split('.').map(Number);
    for(let i=0;i<3;i++) {if(a[i]!==b[i]) return a[i]>b[i];}
    return false;
  };
  async function check() {
    const cached=(await chrome.storage.local.get('qqRelease')).qqRelease;
    if(cached && Date.now()-cached.checkedAt<6*60*60*1000) return {...cached,available:newer(cached.version,chrome.runtime.getManifest().version)};
    try {
      const response=await fetch(QQ_CONFIG.releaseUrl,{cache:'no-store',signal:AbortSignal.timeout(8000)});
      if(!response.ok) throw new Error('Release unavailable');
      const data=await response.json();
      if(!/^\d+\.\d+\.\d+$/.test(data.version)) throw new Error('Invalid release');
      const release={version:data.version,available:newer(data.version,chrome.runtime.getManifest().version),checkedAt:Date.now()};
      await chrome.storage.local.set({qqRelease:release});
      return release;
    } catch {return cached ? {...cached,available:newer(cached.version,chrome.runtime.getManifest().version)} : {available:false};}
  }
  return {check,newer};
})();
