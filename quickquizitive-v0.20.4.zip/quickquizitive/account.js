/* Background-only account client. Tokens never enter the Norton page. */
const QQAccount = (() => {
  let refreshTask, loginTask;
  const configured = () => /^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(QQ_CONFIG.supabaseUrl) && Boolean(QQ_CONFIG.publishableKey);
  const base64url = bytes => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  async function request(path, body, token) {
    if (!configured()) throw new Error('Account setup is not connected yet.');
    const response = await fetch(QQ_CONFIG.supabaseUrl + path, {
      method: 'POST', headers: {'Content-Type':'application/json', apikey:QQ_CONFIG.publishableKey, ...(token ? {Authorization:`Bearer ${token}`} : {})},
      body:JSON.stringify(body), signal:AbortSignal.timeout(15000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(response.status === 401 ? 'Please sign in again.' : 'Account service unavailable. Please try again.');
      error.status = response.status;
      throw error;
    }
    return data;
  }
  async function storeSession(data) {
    if (!data.access_token || !data.refresh_token || !data.user?.id) throw new Error('Sign-in did not return a valid session.');
    // Discard provider tokens; only retain the Supabase session.
    const session = {access_token:data.access_token,refresh_token:data.refresh_token,expires_at:Math.floor(Date.now()/1000)+Number(data.expires_in || 3600),user:{id:data.user.id,email:data.user.email || ''}};
    await chrome.storage.local.set({qqSession:session});
    return session;
  }
  async function session() {
    const saved = (await chrome.storage.local.get('qqSession')).qqSession;
    if (!saved) throw new Error('Sign in with Google to run QuickQuizitive.');
    if (saved.expires_at > Date.now()/1000+90) return saved;
    if (!refreshTask) refreshTask = request('/auth/v1/token?grant_type=refresh_token',{refresh_token:saved.refresh_token})
      .then(storeSession).catch(async error => {if ([400,401].includes(error.status)) await chrome.storage.local.remove('qqSession'); throw error;}).finally(() => {refreshTask=null;});
    return refreshTask;
  }
  async function login() {
    if (loginTask) return loginTask;
    loginTask = (async () => {
      if (!configured()) throw new Error('Account setup is not connected yet.');
      const verifier = base64url(crypto.getRandomValues(new Uint8Array(48)));
      const challenge = base64url(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier)));
      const redirect = chrome.identity.getRedirectURL('auth');
      const url = new URL(QQ_CONFIG.supabaseUrl+'/auth/v1/authorize');
      url.search = new URLSearchParams({provider:'google',redirect_to:redirect,code_challenge:challenge,code_challenge_method:'s256'});
      const result = new URL(await chrome.identity.launchWebAuthFlow({url:url.href,interactive:true}));
      const expected = new URL(redirect);
      if (result.origin!==expected.origin || result.pathname!==expected.pathname) throw new Error('Unexpected sign-in redirect.');
      if (result.searchParams.get('error')) throw new Error('Sign-in was cancelled or denied.');
      const code = result.searchParams.get('code');
      if (!code) throw new Error('Sign-in did not complete.');
      await storeSession(await request('/auth/v1/token?grant_type=pkce',{auth_code:code,code_verifier:verifier}));
      return status();
    })().finally(() => {loginTask=null;});
    return loginTask;
  }
  async function rpc(name,args={}) {
    const current = await session();
    return request('/rest/v1/rpc/'+name,args,current.access_token);
  }
  async function status() {
    if (!configured()) return {configured:false,signedIn:false};
    if (!(await chrome.storage.local.get('qqSession')).qqSession) return {configured:true,signedIn:false};
    const current = await session();
    return {configured:true,signedIn:true,email:current.user.email,...await rpc('qq_account')};
  }
  async function logout() {
    const saved = (await chrome.storage.local.get('qqSession')).qqSession;
    await chrome.storage.local.remove('qqSession');
    if (saved) await request('/auth/v1/logout?scope=local',{},saved.access_token).catch(()=>{});
  }
  return {configured,login,logout,status,rpc};
})();
