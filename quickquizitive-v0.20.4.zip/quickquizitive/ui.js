/* Expanded panel; compact Run/Stop uses the same background authorization path. */
const $ = id => document.getElementById(id);
let busy=false;
function notice(message='') {$('notice').textContent=message;$('notice').hidden=!message;}
async function send(type,action) {
  const response=await chrome.runtime.sendMessage({type,action});
  if(response?.error) throw new Error(response.error);
  return response;
}
function renderAccount(account) {
  $('signin').hidden=!account.configured || account.signedIn;
  $('signout').hidden=!account.signedIn;
  $('start').disabled=!account.configured || !account.signedIn || busy;
  $('privacy').hidden=Boolean(account.signedIn);
  $('plan').textContent=account.signedIn ? `${account.plan==='paid'?'Paid':'Free'} plan` : 'Your account';
  $('account-copy').textContent=!account.configured ? 'Account setup is not connected yet.' : !account.signedIn ? 'Sign in to get your monthly assignment allowance.' : `${account.remaining} of ${account.limit} assignments remaining`;
  $('reset').hidden=!account.resetAt;
  if(account.resetAt) $('reset').textContent=`Resets ${new Date(account.resetAt).toLocaleDateString(undefined,{timeZone:'UTC'})} UTC. Restarts of an authorized assignment are included.`;
}
async function refresh() {
  try {
    const response=await send('QQ_ACCOUNT','status');
    renderAccount(response.account);
    $('update').hidden=!response.update?.available;
    if(response.update?.available) $('update').textContent=`Version ${response.update.version} is available. Download update ↗`;
  } catch(error) {renderAccount({configured:true,signedIn:false});notice(error.message);$('start').disabled=true;}
}
$('signin').addEventListener('click',async()=>{
  $('signin').disabled=true;notice();
  try {renderAccount((await send('QQ_ACCOUNT','login')).account);} catch(error) {notice(error.message);}
  finally {$('signin').disabled=false;}
});
$('signout').addEventListener('click',async()=>{
  try {await send('QQ_ACCOUNT','logout');await refresh();} catch(error) {notice(error.message);}
});
$('start').addEventListener('click',async()=>{
  if(busy)return;busy=true;$('start').disabled=true;notice();
  try {await send('QUESTION_HELPER_COMMAND','start');} catch(error) {notice(error.message);}
  finally {busy=false;await refresh();}
});
$('stop').addEventListener('click',async()=>{
  try {await send('QUESTION_HELPER_COMMAND','stop');} catch(error) {notice(error.message);}
});
if(window.parent!==window && typeof ResizeObserver!=='undefined') {
  const resize=()=>window.parent.postMessage({type:'QUESTION_HELPER_RESIZE',height:Math.ceil(document.querySelector('.app').getBoundingClientRect().height)},'https://ncia.wwnorton.com');
  new ResizeObserver(resize).observe(document.querySelector('.app'));resize();
}
if(typeof chrome!=='undefined' && chrome.runtime?.id) refresh();
else {renderAccount({configured:false,signedIn:false});notice('Preview only. Load this folder as a Chrome extension to connect your account.');}

window.addEventListener('focus',()=>{if(typeof chrome!=='undefined' && chrome.runtime?.id) refresh();});
