// Public project details only. Never put a secret/service-role key here.
const QQ_CONFIG = Object.freeze({
  testAssignmentId: null,
  testStopAtScore: null,
  supabaseUrl: 'https://xzwvnobptsymbxmloudb.supabase.co',
  publishableKey: 'sb_publishable_vTklhm1FqqWAtqaOXYzqnA_56cXjwoQ',
  releaseUrl: 'https://brianmcentee.github.io/quickquizitive/release.json',
  downloadPage: 'https://brianmcentee.github.io/quickquizitive/#install'
});
