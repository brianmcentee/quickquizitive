/* Independently written runner. Account tokens never enter this function. */
function inspectAndFill(fill, options = {}) {
  const runnerKey = '__inquizitiveHelperRunnerV4';
  if (fill === 'snapshot') {
    const state = window[runnerKey];
    return state ? {runId:state.runId,running:state.running,answered:state.answered,message:state.message} : null;
  }
  if (fill === 'prepare') {
    if (window[runnerKey]?.running) return {running:true};
    const maximum = /\b100\s*%/.test(document.getElementById('grade_holder')?.textContent || '') ||
      /(?:grade of|current grade is)\s+100\s*%/i.test(document.getElementById('ac_layer_holder_inner')?.textContent || '');
    if (maximum) return {ready:false,error:'This assignment is already at 100%. No use was charged.'};
    const limit=Number(options.stopAtScore);
    const scoreText=document.getElementById('score_amount')?.textContent || '';
    const scoreMatch=scoreText.match(/(?:score is|activity score)\s*([\d,]+)/i);
    const score=Number(scoreMatch?.[1]?.replace(/,/g,''));
    if (Number.isFinite(limit) && limit>0 && Number.isFinite(score) && score>=limit) {
      return {ready:false,error:`Test cutoff reached (${limit} points). Runner remains stopped. No additional use was charged.`};
    }
    if (window.Score?.restoring_session) return {ready:false,error:'Your Norton session is restoring. Wait a moment and click Run again. No use was charged.'};
    // Answer controls disappear/disable after submission. An available Next
    // Question control means feedback, not an unsupported new question.
    const feedbackNext=[...document.querySelectorAll('button')].some(el =>
      !el.disabled && el.textContent.trim()==='Next Question' && el.getClientRects().length && getComputedStyle(el).visibility!=='hidden');
    if (feedbackNext) return {ready:true};
    const preview = inspectAndFill(false);
    if (!preview.includes('Ready to fill')) return {ready:false,error:preview};
    return {ready:true};
  }
  if (fill === 'stop') {
    const state = window[runnerKey];
    if (state) { state.running = false; state.message = 'Stopped by you.'; }
    return state?.message || 'Runner is not active.';
  }
  if (fill === 'status') {
    const state = window[runnerKey];
    return state ? `${state.running ? 'Running' : 'Stopped'}; answered this run: ${state.answered}; notices dismissed: ${state.dismissed || 0}; level screens continued: ${state.levels || 0}. ${state.message}\n\nRecent activity:\n${(state.events || []).slice(-6).join('\n')}` : 'Runner has not been started on this page.';
  }
  if (fill === 'start') {
    if (window[runnerKey]?.running) return 'Already running. Use Stop to pause.';
    const state = { running: true, answered: 0, dismissed: 0, levels: 0, runId: options.runId || null, message: 'Starting…', events: [] };
    window[runnerKey] = state;
    const record = message => {
      state.message = message;
      state.events.push(`${new Date().toLocaleTimeString()} — ${message}`);
      if (state.events.length > 30) state.events.shift();
    };
    const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
    // Wake on render changes; retain a timer fallback for non-DOM engine changes.
    const renderWait = () => typeof MutationObserver === 'undefined' ? sleep(500) : new Promise(resolve => {
      let timer;
      const done = () => { observer.disconnect(); clearTimeout(timer); resolve(); };
      const observer = new MutationObserver(done);
      observer.observe(document.getElementById('main_activity_holder') || document.documentElement,
        {childList:true,subtree:true,attributes:true,attributeFilter:['disabled','style','class']});
      timer = setTimeout(done,500);
    });
    const active = () => state.running && window[runnerKey] === state;
    const visible = el => el && !el.disabled && el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden';
    const nextButton = () => {
      // Prefer the open feedback dialog over the button behind it.
      const dialog = document.getElementById('feed_outer_dialog');
      const dialogNext = dialog && [...dialog.querySelectorAll('button')].find(el => visible(el) && el.textContent.trim() === 'Next Question');
      return dialogNext || [...document.querySelectorAll('button')].find(el => visible(el) && el.textContent.trim() === 'Next Question');
    };
    const maximumReached = () => /\b100\s*%/.test(document.getElementById('grade_holder')?.textContent || '') ||
      /(?:grade of|current grade is)\s+100\s*%/i.test(document.getElementById('ac_layer_holder_inner')?.textContent || '');
    const testCutoffReached = () => {
      const limit=Number(options.stopAtScore);
      if (!Number.isFinite(limit) || limit<=0) return false;
      const text=document.getElementById('score_amount')?.textContent || '';
      const match=text.match(/(?:score is|activity score)\s*([\d,]+)/i);
      const score=Number(match?.[1]?.replace(/,/g,''));
      return Number.isFinite(score) && score>=limit;
    };
    const finished = () => maximumReached() || testCutoffReached();
    const finishedMessage = () => maximumReached() ? 'Stopped: the assignment has reached 100%.' :
      `Stopped at the test score cutoff (${options.stopAtScore} points).`;
    const stop = message => { state.running = false; record(message); };
    const interruptions = async () => {
      const seen = new Set();
      for (let attempt = 0; attempt < 8 && active(); attempt++) {
        if (finished()) return true;
        const dialogs = [...document.querySelectorAll('[role="dialog"], .ui-dialog')].filter(visible);
        // jQuery may expose the same dialog both as a wrapper and a child.
        const outer = dialogs.filter(dialog => !dialogs.some(other => other !== dialog && other.contains(dialog)));
        const dialog = outer.find(el => el.id !== 'feed_outer_dialog' && !el.querySelector('#feed_outer_dialog'));
        if (!dialog) {
          const heading = document.getElementById('option_header');
          const milestoneText = document.getElementById('ac_layer_holder_inner')?.textContent || '';
          const levelScreen = visible(heading) && /you[’']ve made it to level\s+\d+/i.test(heading.textContent);
          const minimumScreen = visible(heading) && /nice work/i.test(heading.textContent) &&
            /answered the minimum number of questions/i.test(milestoneText);
          if (levelScreen || minimumScreen) {
            const back = [...document.querySelectorAll('button')].filter(el => visible(el) && el.textContent.trim() === 'Back to Questions');
            if (back.length !== 1 || seen.has(heading)) {
              stop('Level screen is waiting for Back to Questions. Review the page.');
              return false;
            }
            seen.add(heading);
            record(minimumScreen ? 'Continuing beyond the minimum-question milestone…' : 'Continuing past a level milestone…');
            back[0].click();
            state.levels++;
            await sleep(300);
            continue;
          }
          return true;
        }
        const text = dialog.textContent.replace(/\s+/g, ' ').trim();
        const bonus = /\bbonus\s+of\s+\d+\s+points\b/i.test(text) &&
          /(?:questions? in a row correctly|hard work is paying off)/i.test(text);
        const encouragement = /(?:you[’']ve answered\s+\d+\s+questions? in a row correctly|your hard work is paying off)/i.test(text);
        const confidenceTip = /you seem to know this content better than you think you do/i.test(text) &&
          /increase your confidence level/i.test(text);
        const breakNotice = /(?:time (?:for|to take) a break|take a (?:short )?break|ready to continue)/i.test(text);
        if (!bonus && !encouragement && !confidenceTip && !breakNotice) {
          stop(`Unrecognized dialog needs your attention: ${text.slice(0, 160)}`);
          return false;
        }
        const labels = breakNotice ? ['ok', 'continue', 'keep going', 'resume', 'continue answering questions'] : ['ok', 'continue', 'keep going'];
        const buttons = [...dialog.querySelectorAll('button')].filter(el => visible(el) && labels.includes(el.textContent.trim().toLowerCase()));
        if (buttons.length !== 1 || seen.has(dialog)) {
          stop('A notice is waiting for an available Continue/OK button. Review the page.');
          return false;
        }
        seen.add(dialog);
        record(bonus ? 'Dismissing earned-bonus notice…' : 'Continuing past a study notice…');
        buttons[0].click();
        state.dismissed++;
        await sleep(300);
      }
      if (active()) stop('Too many consecutive notices. Review the page.');
      return false;
    };
    const waitFor = async (predicate, attempts = 80) => {
      const deadline = Date.now() + attempts * 500;
      for (let i = 0; active() && (typeof MutationObserver === 'undefined' ? i < attempts : Date.now() < deadline); i++) {
        if (!await interruptions() || !active()) return false;
        if (!window.Score?.restoring_session && predicate()) return true;
        await renderWait();
      }
      return false;
    };
    // Keep the loop in the page so closing the extension popup doesn't kill it.
    (async () => {
      try {
        while (active()) {
          if (!await interruptions() || !active()) break;
          if (finished()) { stop(finishedMessage()); break; }
          record('Waiting for the question to render…');
          if (!await waitFor(() => window.FAQ?.current_question &&
            (nextButton() || [...(document.getElementById('main_question_holder')?.querySelectorAll('select, button.mc_choice[choice], button.tf_choice[choice], button.imageclick_aria_button[data-choice-id], .passageclick_target[role="button"][data-target-id]') || [])].some(visible)))) {
            if (active()) stop('No question controls appeared within 40 seconds. Open the assignment question or review the page notice.');
            break;
          }
          if (!active()) break;
          // Session restoration must finish before interpreting a rendered question.
          if (window.Score?.restoring_session) { await sleep(500); continue; }
          const question = window.FAQ?.current_question;
          if (!question) { stop('No current question. Review the page.'); break; }
          let next = nextButton();
          if (!next) {
            const preview = inspectAndFill(false);
            if (!preview.includes('Ready to fill')) { stop(preview); break; }
            record('Filling current question…');
            const result = inspectAndFill(true);
            if (!/^(Selected \d+ dropdown answers|Clicked one answer|Clicked \d+ image answers|Clicked \d+ passage answers)/.test(result)) { stop(result); break; }
            state.answered++;
            record('Waiting for question feedback…');
            if (!await waitFor(() => finished() || Boolean(nextButton()))) {
              if (active()) stop('No Next Question button appeared within 40 seconds. Review feedback; no retry was submitted.');
              break;
            }
            if (!active()) break;
            if (finished()) { stop(finishedMessage()); break; }
            next = nextButton();
          }
          const feedback = document.getElementById('bet_specifics')?.textContent || '';
          if (/\blost\b/i.test(feedback)) { stop('The page reports lost points. Review this question.'); break; }
          if (!await interruptions() || !active()) break;
          next = nextButton();
          if (!next || !active()) break;
          record('Opening next question…');
          next.click();
          if (!await waitFor(() => window.FAQ?.current_question !== question,40)) {
            if (!active()) break;
            // Retry only navigation, once, when the exact original feedback control
            // and question still exist. Never repeat an answer submission.
            if (window.FAQ?.current_question !== question || nextButton() !== next || !next.isConnected || !visible(next)) {
              stop('Question navigation stalled. Review the page.'); break;
            }
            record('Retrying the unchanged Next Question control once…');
            next.click();
            if (!await waitFor(() => window.FAQ?.current_question !== question,40)) {
              if (active()) stop('The question did not change within 40 seconds.');
              break;
            }
          }
          // Allow the new question to render before reading its controls.
          await sleep(750);
        }
      } catch (error) { stop(`Stopped: ${error.message}`); }
    })();
    return 'Runner started. Stops automatically at 100%. Use Stop to end the run.';
  }
  if (fill === true && window[runnerKey]?.running && window[runnerKey].message !== 'Filling current question…') {
    return 'The runner is active. Stop it before filling manually.';
  }
  const root = document.getElementById('main_question_holder');
  const question = window.FAQ?.current_question;
  if (!root) return 'No question controls are displayed. If a study notice is open, Start automatic runner will dismiss supported notices and wait for the question.';
  if (!question) return 'The question engine is not ready. Start automatic runner will wait up to 40 seconds; if it remains unavailable, refresh the assignment.';
  const trueFalse = [...root.querySelectorAll('button.tf_choice[choice]')].filter(el => !el.disabled && el.getClientRects().length);
  if (trueFalse.length) {
    const raw = Array.isArray(question.correct_answer) && question.correct_answer.length === 1 ? question.correct_answer[0] : question.correct_answer;
    const answer = raw === true || raw === 'true' ? 'true' : raw === false || raw === 'false' ? 'false' : null;
    if (answer === null) return 'Unsupported true/false answer metadata. Nothing changed.';
    const matches = trueFalse.filter(el => el.getAttribute('choice') === answer);
    if (matches.length !== 1) return 'True/false answer control is missing or ambiguous. Nothing changed.';
    if (!fill) return 'True/false answer mapped successfully. Ready to fill; nothing changed.';
    if (window.FAQ?.current_question !== question || !matches[0].isConnected || matches[0].disabled) return 'Question changed. Nothing selected.';
    matches[0].click();
    return 'Clicked one answer. Review the page feedback.';
  }
  const passages = [...root.querySelectorAll('.passageclick_target[role="button"][data-target-id]')].filter(el =>
    !el.disabled && el.getAttribute('aria-disabled') !== 'true' && el.getClientRects().length);
  if (passages.length && String(question.type).toLowerCase() === 'passageclick') {
    const answers = question.correct_answer;
    if (!Array.isArray(answers) || !answers.length || !answers.every(value => [true,false,'true','false'].includes(value))) {
      return `Unsupported passage answer metadata: controls=${passages.length}, type=${Array.isArray(answers)?'array':typeof answers}. Nothing changed.`;
    }
    const controlIds = passages.map(el => el.getAttribute('data-target-id'));
    if (new Set(controlIds).size !== controlIds.length || controlIds.some(id =>
      !/^\d+$/.test(id || '') || !Object.prototype.hasOwnProperty.call(answers,Number(id)))) {
      return 'Passage target IDs do not match the indexed answer data. Nothing changed.';
    }
    if (passages.some(el => el.getAttribute('aria-pressed') === 'true' || /(?:selected|correct|incorrect|clicked)/i.test(el.className))) {
      return 'This passage already has selections. Review it before restarting. Nothing changed.';
    }
    const positiveIds = answers.flatMap((value,index) => value === true || value === 'true' ? [String(index)] : []);
    if (!positiveIds.length) return 'No positive passage answers found. Nothing changed.';
    const plan = positiveIds.map(id => passages.filter(el => el.getAttribute('data-target-id') === id));
    if (plan.some(matches => matches.length !== 1)) return 'Passage answer targets are missing or ambiguous. Nothing changed.';
    if (!fill) return `${plan.length} passage answers mapped successfully. Ready to fill; nothing changed.`;
    let count=0;
    for (const [target] of plan) {
      if (window.FAQ?.current_question !== question || !target.isConnected || target.getAttribute('aria-disabled') === 'true') {
        return `Stopped after ${count} passage selections because the question changed.`;
      }
      target.click(); count++;
    }
    return `Clicked ${count} passage answers. Review the page feedback.`;
  }
  const hotspots = [...root.querySelectorAll('button.imageclick_aria_button[data-choice-id]')].filter(el => !el.disabled && el.getClientRects().length);
  if (hotspots.length && String(question.type).toLowerCase() === 'imageclick') {
    const metadata = question.correct_answer;
    let ids;
    if (Array.isArray(metadata) && metadata.length > 0 &&
      metadata.every(value => [true, false, 'true', 'false'].includes(value))) {
      const controlIds = hotspots.map(el => el.getAttribute('data-choice-id'));
      if (new Set(controlIds).size !== controlIds.length || controlIds.some(id =>
        !/^\d+$/.test(id || '') || !Object.prototype.hasOwnProperty.call(metadata, Number(id)))) {
        return 'Image hotspot controls do not match the indexed answer data. Nothing changed.';
      }
      // Norton can retain false entries for regions with no rendered button.
      // Positive entries still must map to exactly one actual control below.
      ids = metadata.flatMap((value, index) => value === true || value === 'true' ? [String(index)] : []);
    } else if (['string', 'number'].includes(typeof metadata) && /^\d+$/.test(String(metadata))) {
      ids = [String(metadata)];
    } else if (Array.isArray(metadata) && metadata.length === 1 &&
      ['string', 'number'].includes(typeof metadata[0]) && /^\d+$/.test(String(metadata[0]))) {
      ids = [String(metadata[0])];
    } else {
      let shape;
      try { shape = JSON.stringify(metadata)?.slice(0, 240) || String(metadata); }
      catch { shape = typeof metadata; }
      return `Unsupported image-hotspot answer metadata: type=${String(question.type)}, controls=${hotspots.length}, answer=${shape}. Nothing changed.`;
    }
    if (!ids.length) return 'No positive image answers found. Nothing changed.';
    const plan = ids.map(id => hotspots.filter(el => el.getAttribute('data-choice-id') === id));
    if (plan.some(matches => matches.length !== 1)) return 'Image hotspot IDs are missing or ambiguous. Nothing changed.';
    if (!fill) return `${ids.length} image answers mapped successfully. Ready to fill; nothing changed.`;
    let count = 0;
    for (const [button] of plan) {
      if (window.FAQ?.current_question !== question || !button.isConnected || button.disabled) return `Stopped after ${count} image selections because the controls changed.`;
      button.click();
      count++;
    }
    return `Clicked ${count} image answers. Review the page feedback.`;
  }
  const buttons = [...root.querySelectorAll('button.mc_choice[choice]')].filter(el => !el.disabled && el.getClientRects().length);
  if (buttons.length) {
    const metadata = question.correct_answer;
    const answer = Array.isArray(metadata) && metadata.length === 1 ? metadata[0] : metadata;
    if (!['string', 'number'].includes(typeof answer) || !/^\d+$/.test(String(answer))) {
      return 'Unsupported multiple-choice answer metadata. Nothing changed.';
    }
    const matches = buttons.filter(button => button.getAttribute('choice') === String(answer));
    if (matches.length !== 1) return 'Multiple-choice answer did not match exactly one button. Nothing changed.';
    if (!fill) return 'Multiple-choice answer mapped successfully. Ready to fill; nothing changed.';
    if (window.FAQ?.current_question !== question || !matches[0].isConnected) return 'Question changed. Nothing selected.';
    matches[0].click();
    return 'Clicked one answer. Review the page feedback.';
  }
  const selects = [...root.querySelectorAll('select')].filter(el => el.getClientRects().length && !el.disabled);
  if (!selects.length) return 'Unsupported question controls: no supported multiple-choice, image-hotspot, passage-selection, or dropdown controls found. Nothing changed.';
  if (question.correct_answer == null) {
    return 'Unsupported: this question does not expose correct_answer metadata. Nothing changed.';
  }
  const answers = Array.isArray(question.correct_answer)
    ? question.correct_answer : [question.correct_answer];
  const matching = selects.every(select => /^sr_target_select_\d+$/.test(select.id)) &&
    ['matching', 'dragdrop'].includes(String(question.type).toLowerCase());
  const targetToChoice = new Map();
  if (matching) {
    // Matching metadata lists targets for each source choice. The UI instead
    // asks for a source choice at each target, so invert that relationship.
    for (let choice = 0; choice < answers.length; choice++) {
      const targets = Array.isArray(answers[choice]) ? answers[choice] : [answers[choice]];
      for (const target of targets) {
        if (target === null || target === undefined || target === '') continue;
        if (!['number', 'string'].includes(typeof target) || !/^\d+$/.test(String(target))) {
          return 'Unsupported matching target metadata. Nothing changed.';
        }
        const id = String(Number(target));
        if (targetToChoice.has(id) && targetToChoice.get(id) !== String(choice)) {
          return 'This target requires multiple matches; that format is not supported. Nothing changed.';
        }
        targetToChoice.set(id, String(choice));
      }
    }
    const ids = new Set(selects.map(select => String(Number(select.id.replace('sr_target_select_', '')))));
    if (ids.size !== selects.length || [...targetToChoice.keys()].some(id => !ids.has(id))) {
      return 'Matching targets do not match the available controls. Nothing changed.';
    }
  } else if (answers.length !== selects.length) {
    return `Unsupported answer structure: type ${String(question.type || 'unknown')}, ${answers.length} answer entries, ${selects.length} controls. Nothing changed.`;
  }
  const normalize = value => String(value ?? '').replace(/\s+/g, ' ').trim().toLowerCase();
  const choices = question.choices;
  const plan = selects.map((select, index) => {
    if (matching) {
      const targetId = String(Number(select.id.replace('sr_target_select_', '')));
      const value = targetToChoice.get(targetId);
      if (value === undefined) return null;
      const options = [...select.options].filter(option => !option.disabled && option.value === value);
      return options.length === 1 ? { select, value } : null;
    }
    // Accessible controls for drag cards are shuffled with the cards. The ID,
    // rather than the DOM position, identifies the original choice.
    const cardId = /^sr_choice_(\d+)$/.exec(select.id);
    const categoryValues = new Set([...select.options].map(option => option.value));
    if (cardId && categoryValues.has('ms_correct_answers') && categoryValues.has('ms_incorrect_answers')) {
      const choiceIndex = Number(cardId[1]);
      if (!Object.prototype.hasOwnProperty.call(answers, choiceIndex)) return null;
      const flag = answers[choiceIndex];
      // Do not coerce arbitrary strings, indices or unknown metadata to true.
      const truth = flag === true || flag === 'true';
      const falsehood = flag === false || flag === 'false';
      if (!truth && !falsehood) return null;
      return { select, value: truth ? 'ms_correct_answers' : 'ms_incorrect_answers' };
    }
    const answer = answers[index];
    const choice = choices && Object.prototype.hasOwnProperty.call(choices, answer) ? choices[answer] : null;
    const choiceText = typeof choice === 'string' ? choice : choice?.text;
    const plain = document.createElement('div');
    plain.innerHTML = choiceText == null ? '' : String(choiceText);
    const text = normalize(plain.textContent);
    const candidates = [...select.options].filter(option => !option.disabled && option.value !== '' &&
      (option.value === String(answer) || (text && normalize(option.textContent) === text)));
    return candidates.length === 1 ? { select, value: candidates[0].value } : null;
  });
  if (plan.some(item => !item)) {
    return `Unsupported answer mapping. Type: ${String(question.type || 'unknown')}; controls: ${selects.length}; answer entries: ${answers.length}; entry types: ${[...new Set(answers.map(value => typeof value))].join(', ')}. Nothing changed.`;
  }
  if (new Set(plan.map(item => item.select.id)).size !== plan.length && plan.some(item => /^sr_choice_/.test(item.select.id))) {
    return 'Duplicate answer control IDs. Nothing changed.';
  }
  if (!fill) return `${plan.length} answer controls mapped successfully. Ready to fill; nothing changed.`;
  const initialQuestion = question;
  let count = 0;
  for (const item of plan) {
    if (window.FAQ?.current_question !== initialQuestion || !item.select.isConnected) {
      return `Stopped after ${count} selections because the question changed.`;
    }
    try {
      item.select.value = item.value;
      item.select.dispatchEvent(new Event('input', { bubbles: true }));
      item.select.dispatchEvent(new Event('change', { bubbles: true }));
    } catch (error) {
      return `Stopped after ${count} selections: ${error.message}`;
    }
    count++;
  }
  return `Selected ${count} dropdown answers. Review the page result.`;
}

