# QuickQuizitive v0.20.2

Install in desktop Chrome: unzip, enable Developer mode at chrome://extensions, choose Load unpacked, and select the quickquizitive folder containing manifest.json. Keep the folder somewhere permanent.

Sign in with Google, open a Norton InQuizitive question, and click Run. The free plan includes 3 distinct assignments per UTC calendar month. Restarting an authorized assignment within the same month does not consume another use. The expanded panel shows your remaining allowance; minimizing keeps Run and Stop visible.

The runner stops at 100%, on unsupported question formats, unfamiliar dialogs, reported lost points, or stalled progress. The test-only Chapter 2 cutoff is disabled in this public release. Some question formats remain unsupported; compatibility with every course is not guaranteed.

Updates: the extension checks a public version file and links to the download page. ZIP installations require manually replacing the extension files, reloading the extension, and refreshing Norton. It does not silently install updates.

Privacy: https://brianmcentee.github.io/quickquizitive/privacy.html
Support: brianmcenteecool@gmail.com

Account/assignment allowance records are stored in Supabase. The extension does not send Norton passwords or question content to the backend. Do not add service-role or OAuth client secrets to extension files.

Independent software, not affiliated with W. W. Norton. Use in accordance with your course requirements.
