# QuickQuizitive v0.19

## Update or install

If a runner is active, stop it first. Open chrome://extensions and reload QuickQuizitive to load the updated scripts. Refresh the assignment to remove any older floating panel, then click QuickQuizitive in Chrome's extensions menu.

For a first installation, enable Developer mode at chrome://extensions, choose Load unpacked, and select this folder.

## Controls

The panel has only **Run** and **Stop**. The status card, compatibility button, and automatic status polling have been removed. Drag the top bar to move the panel; arrow keys also move it when the bar is focused. Minimize to show just Run and Stop. Expand to restore the full interface. Outside clicks leave the panel open.

The X hides the panel without stopping the runner. Reopen it from Chrome's extensions menu. Refreshing or navigating the assignment removes the panel and stops the injected runner.

## Continuing at 100%

When Run sees that the assignment already displays 100%, or reaches 100% during a run, a browser confirmation explains that the maximum grade has been reached and asks whether to continue answering additional questions. Cancel stops the run. Confirm allows the same run to continue beyond 100% until Stop or another stop condition. The confirmation is requested once per run; a new run asks again when appropriate. If browser dialogs are suppressed, continuation is not approved and the run stops.

The old testing mode and 10-/50-question run limits have been removed. Unsupported or ambiguous questions, unfamiliar dialogs, lost points, and progress timeouts still stop the runner.

Command failures appear as a browser alert. The panel no longer displays run status or activity logs.

## Supported formats

Multiple choice, True/False, supported native dropdown blanks, correct/incorrect drag cards through accessible controls, supported matching questions, and image hotspots. Missing or ambiguous answer data stops without guessing. The runner handles the observed bonus, confidence-tip, level, and minimum-question notices using their normal page controls.

## Data and permissions

The helper uses activeTab and scripting. Compact controls send commands through the extension background worker. It makes no external network requests, uses no AI key, and does not change recorded timing or directly change scores. The floating interface is isolated from page styles.

## Verification

The runner previously completed the observed assignment at a displayed 100%, and a map-hotspot answer was separately accepted live. Version 0.17 passed 14 runner regression scenarios plus four confirmation scenarios: approval and refusal when starting at 100% or reaching it during a run. Approved fixtures continued for 55 answers with exactly one prompt, verifying removal of the old caps; refusal submitted no further answers. The simplified interface was visually checked and contained exactly the three requested actions. This update's confirmation behavior has not yet been verified live in Chrome.

Version 0.18 passed JavaScript syntax checks for all three scripts and all 14 runner regression scenarios. The rendered iframe was verified to expose exactly Run and Stop. The existing 100% confirmation logic is unchanged.
