importScripts('popup.js');
const commands = new Set(['start', 'stop']);
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.type !== 'QUESTION_HELPER_COMMAND') return;
  const tab = sender.tab;
  if (!tab?.id || !commands.has(message.action) || new URL(tab.url).hostname !== 'ncia.wwnorton.com') {
    reply({error: 'Open the helper on an InQuizitive assignment.'});
    return;
  }
  chrome.scripting.executeScript({target:{tabId:tab.id},world:'MAIN',func:inspectAndFill,args:[message.action]})
    .then(results=>reply({result:results[0]?.result || 'No result returned.'}))
    .catch(error=>reply({error:error.message}));
  return true;
});
chrome.action.onClicked.addListener(async tab => {
  if (!tab.id || !tab.url || new URL(tab.url).hostname !== 'ncia.wwnorton.com') return;
  await chrome.scripting.executeScript({target:{tabId:tab.id},files:['floating.js']});
});
