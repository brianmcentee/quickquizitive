(() => {
  const id = 'question-helper-floating-panel';
  const existing = document.getElementById(id);
  if (existing) { existing.style.display = 'block'; existing.dispatchEvent(new Event('helper-reopen')); return; }
  const host = document.createElement('div');
  host.id = id;
  host.style.cssText = 'position:fixed;top:24px;right:24px;z-index:2147483647;display:block;color-scheme:dark;';
  const shadow = host.attachShadow({mode:'open'});
  shadow.innerHTML = `
    <style>
    :host{font:13px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#eef3ef}
    *{box-sizing:border-box}.panel{width:380px;max-width:calc(100vw - 16px);background:#101414;border:1px solid #3a4b40;border-radius:15px;box-shadow:0 16px 70px #0006;overflow:hidden}
    .bar{display:flex;align-items:center;gap:9px;padding:10px 12px;border-bottom:1px solid #2a3431;cursor:grab;touch-action:none;user-select:none;background:#1b2420}
    .grip{color:#8ca894;font-size:18px;letter-spacing:-2px}.title{flex:1;font-size:11px;font-weight:600}.hint{font-size:9px;color:#8ca894;margin-left:6px;font-weight:400}
    button{font:inherit;cursor:pointer}button:focus-visible,.bar:focus-visible{outline:2px solid #b9f5ca;outline-offset:-3px}.icon{border:0;background:transparent;color:#b9ccbf;width:28px;height:26px;border-radius:5px;font-size:18px}.icon:hover{background:#34453b}
    iframe{display:block;width:100%;height:min(560px,calc(100dvh - 110px));border:0;background:#101414}.mini{display:none;padding:10px;gap:8px}.mini button{border:1px solid transparent;border-radius:8px;height:37px;font-size:12px;font-weight:600}.run{background:#b9f5ca;color:#12261a;flex:1}.stop{background:#302321;color:#e4b6ae;border-color:#49312d!important;flex:1}
    :host(.compact) .panel{width:236px}:host(.compact) iframe{display:none}:host(.compact) .mini{display:flex}:host(.compact) .hint{display:none}.message{display:none;font-size:10px;color:#a8bcb0;padding:0 10px 10px;max-width:235px;max-height:70px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere}:host(.compact) .message:not(:empty){display:block}
    </style>
    <section class="panel" aria-label="QuickQuizitive floating panel">
      <div class="bar" tabindex="0" aria-label="Move QuickQuizitive. Drag or use arrow keys."><span class="grip" aria-hidden="true">\u283f</span><span class="title">QuickQuizitive<span class="hint">DRAG TO MOVE</span></span><button class="icon toggle" aria-label="Minimize panel" title="Minimize">\u2212</button><button class="icon close" aria-label="Hide panel" title="Hide panel (runner keeps running)">\u00d7</button></div>
      <iframe title="QuickQuizitive controls"></iframe>
      <div class="mini"><button class="run">\u25b6 Run</button><button class="stop">\u25a0 Stop</button></div><div class="message" role="status"></div>
    </section>`;
  shadow.querySelector('iframe').src = chrome.runtime.getURL('popup.html');
  document.documentElement.append(host);
  const bar = shadow.querySelector('.bar');
  const toggle = shadow.querySelector('.toggle');
  const frame = shadow.querySelector('iframe');
  const panelURL = chrome.runtime.getURL('popup.html');
  const restoreFrame = () => {
    // srcdoc takes precedence over src, even when it is an empty string.
    // Restore our packaged account UI whenever the user reopens/expands it.
    if (frame.hasAttribute('srcdoc') || frame.src !== panelURL) {
      frame.removeAttribute('srcdoc');
      frame.src = panelURL;
    }
  };
  let desiredHeight = 560;
  const clamp = () => {
    const rect = host.getBoundingClientRect();
    host.style.left = `${Math.max(8,Math.min(rect.left,innerWidth-rect.width-8))}px`;
    host.style.top = `${Math.max(8,Math.min(rect.top,innerHeight-rect.height-8))}px`;
    host.style.right = 'auto';
  };
  const panel = shadow.querySelector('.panel');
  let motion = [];
  let motionId = 0;
  const setCompact = small => {
    const from = panel.getBoundingClientRect();
    const fromHost = host.getBoundingClientRect();
    const token = ++motionId;
    motion.forEach(animation => animation.cancel());
    motion = [];
    host.classList.toggle('compact',small);
    if (!small) restoreFrame();
    toggle.textContent=small?'\uff0b':'\u2212';
    toggle.setAttribute('aria-label',small?'Expand panel':'Minimize panel');
    toggle.setAttribute('aria-expanded',String(!small));
    toggle.title=small?'Expand':'Minimize';
    clamp();
    const to = panel.getBoundingClientRect();
    const toHost = host.getBoundingClientRect();
    if (matchMedia('(prefers-reduced-motion: reduce)').matches || !panel.animate) return;
    const timing={duration:240,easing:'cubic-bezier(.22,1,.36,1)'};
    motion = [
      panel.animate([{width:`${from.width}px`,height:`${from.height}px`},
        {width:`${to.width}px`,height:`${to.height}px`}],timing),
      host.animate([{left:`${fromHost.left}px`,top:`${fromHost.top}px`},
        {left:`${toHost.left}px`,top:`${toHost.top}px`}],timing),
      (small?shadow.querySelector('.mini'):frame).animate([
        {opacity:0,transform:'translateY(-4px)'},{opacity:1,transform:'translateY(0)'}],timing)
    ];
    Promise.all(motion.map(animation => animation.finished)).then(() => {
      if (token===motionId) { motion=[];clamp(); }
    }).catch(() => {}); // Rapid toggles cancel the previous transition.
  };
  toggle.setAttribute('aria-expanded','true');
  host.addEventListener('helper-reopen',()=>setCompact(false));
  toggle.addEventListener('click',()=>setCompact(!host.classList.contains('compact')));
  shadow.querySelector('.close').addEventListener('click',()=>{host.style.display='none';});
  let drag;
  bar.addEventListener('pointerdown',event=>{
    if(event.target.closest('button') || event.button!==0)return;
    const rect=host.getBoundingClientRect();drag={x:event.clientX,y:event.clientY,left:rect.left,top:rect.top};bar.setPointerCapture(event.pointerId);frame.style.pointerEvents='none';bar.style.cursor='grabbing';event.preventDefault();
  });
  bar.addEventListener('pointermove',event=>{
    if(!drag)return;host.style.left=`${drag.left+event.clientX-drag.x}px`;host.style.top=`${drag.top+event.clientY-drag.y}px`;host.style.right='auto';clamp();
  });
  const endDrag=()=>{drag=null;frame.style.pointerEvents='';bar.style.cursor='';};
  bar.addEventListener('pointerup',endDrag);bar.addEventListener('pointercancel',endDrag);bar.addEventListener('lostpointercapture',endDrag);
  bar.addEventListener('keydown',event=>{
    if(event.target!==bar || !['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;
    event.preventDefault();const r=host.getBoundingClientRect();const step=event.shiftKey?30:10;host.style.left=`${r.left+(event.key==='ArrowRight'?step:event.key==='ArrowLeft'?-step:0)}px`;host.style.top=`${r.top+(event.key==='ArrowDown'?step:event.key==='ArrowUp'?-step:0)}px`;host.style.right='auto';clamp();
  });
  const fitFrame = () => { frame.style.height = `${Math.min(desiredHeight,Math.max(120,innerHeight-110))}px`; clamp(); };
  window.addEventListener('message', event => {
    const frameURL = new URL(chrome.runtime.getURL('popup.html'),location.href);
    const frameOrigin = frameURL.protocol === 'chrome-extension:' ? `chrome-extension://${frameURL.host}` : frameURL.origin;
    if (event.source !== frame.contentWindow || event.origin !== frameOrigin || event.data?.type !== 'QUESTION_HELPER_RESIZE') return;
    const height = Number(event.data.height);
    if (!Number.isFinite(height) || height < 100 || height > 2000) return;
    desiredHeight = height; fitFrame();
  });
  window.addEventListener('resize',fitFrame);
  const command=async action=>{
    try {
      const response = await chrome.runtime.sendMessage({type:'QUESTION_HELPER_COMMAND',action});
      if (response?.error) window.alert(response.error);
    } catch (error) { window.alert(error.message); }

  };
  shadow.querySelector('.run').addEventListener('click',()=>command('start'));
  shadow.querySelector('.stop').addEventListener('click',()=>command('stop'));
  const completion=shadow.querySelector('.message');
  const updateCompletion=async()=>{if(!host.isConnected){clearInterval(completionTimer);return;}if(host.style.display==='none' || document.hidden)return;try{const response=await chrome.runtime.sendMessage({type:'QQ_RUN_STATUS'});completion.textContent=response?.snapshot?.completed?'✓ Completed · 100%':'';}catch{completion.textContent='';}};
  const completionTimer=setInterval(updateCompletion,1500);updateCompletion();
  clamp();
})();
