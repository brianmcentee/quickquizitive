importScripts('config.js','account.js','updates.js','popup.js');
const pending = new Map();
const validTab = tab => tab?.id && /^https:\/\/ncia\.wwnorton\.com\/\d+(?:[/?#]|$)/.test(tab.url || '');
const page = async (tabId,action,options={}) => (await chrome.scripting.executeScript({target:{tabId},world:'MAIN',func:inspectAndFill,args:[action,options]}))[0]?.result;
const runs = async () => (await chrome.storage.local.get('qqRuns')).qqRuns || {};
// Serialize writes even when multiple tabs submit commands at once.
let writes = Promise.resolve();
function saveRun(tabId,value) {
  const task=writes.then(async()=>{const all=await runs(); if(value) all[tabId]=value; else delete all[tabId]; await chrome.storage.local.set({qqRuns:all});});
  writes=task.catch(()=>{}); return task;
}
async function settle(tabId,run,snapshot) {
  if (snapshot?.runId!==run.runId) snapshot=null;
  const answered = snapshot?.answered>0 || run.answered>0 || (!snapshot && run.running);
  if (!run.settled && (answered || !snapshot?.running)) {
    await QQAccount.rpc('qq_usage',{p_action:answered?'commit':'release',p_assignment_id:run.assignmentId,p_request_id:run.runId});
    run.settled=true;
  }
  run.answered=Math.max(run.answered || 0,snapshot?.answered || 0);
  run.running=Boolean(snapshot?.running);
  run.message=snapshot?.message || 'Page closed or refreshed. Click Run to resume.';
  // Account details and question text are deliberately excluded from this local record.
  await saveRun(tabId,run.running || !run.settled ? run : null);
}
async function monitor() {
  for(const [tabId,run] of Object.entries(await runs())) {
    if(pending.has(Number(tabId))) continue;
    let snapshot;
    try {snapshot=await page(Number(tabId),'snapshot');} catch {}
    try {await settle(tabId,run,snapshot);} catch { /* Leave pending settlement for the next alarm. */ }
  }
}
async function start(tab) {
  if(pending.has(tab.id)) return pending.get(tab.id).promise;
  const control={cancelled:false};
  control.promise=(async()=>{
    await QQAccount.status();
    if(control.cancelled) throw new Error('Start cancelled.');
    const prior=(await runs())[tab.id];
    if(prior) await settle(tab.id,prior,await page(tab.id,'snapshot'));
    const assignmentId=new URL(tab.url).pathname.split('/')[1];
    const stopAtScore=assignmentId===QQ_CONFIG.testAssignmentId ? QQ_CONFIG.testStopAtScore : null;
    const ready=await page(tab.id,'prepare',{stopAtScore});
    if(ready.running) return {result:'Already running.'};
    if(!ready.ready) throw new Error(ready.error);
    if(control.cancelled) throw new Error('Start cancelled.');
    const runId=crypto.randomUUID();
    const authorization=await QQAccount.rpc('qq_usage',{p_action:'reserve',p_assignment_id:assignmentId,p_request_id:runId});
    if(!authorization.allowed) {
      const messages={allowance_reached:'Your monthly allowance is used. You can resume an authorized assignment or wait for the reset.',assignment_busy:'This assignment is starting in another tab. Try again shortly.',account_disabled:'This account is disabled.'};
      throw new Error(messages[authorization.reason] || 'This run was not authorized.');
    }
    const run={assignmentId,runId,answered:0,running:false,settled:authorization.reason==='already_authorized'};
    await saveRun(tab.id,run);
    try {
      if(control.cancelled) throw new Error('Start cancelled.');
      const result=await page(tab.id,'start',{runId,stopAtScore});
      const snapshot=await page(tab.id,'snapshot');
      if(control.cancelled) {await page(tab.id,'stop'); snapshot.running=false;}
      await settle(tab.id,run,snapshot);
      if(!snapshot?.running && !snapshot?.answered) throw new Error(snapshot?.message || 'Run did not start. No use was charged.');
      return {result,account:await QQAccount.status()};
    } catch(error) {
      // Check actual progress before releasing: a lost response must not refund submitted work.
      let snapshot;
      try {snapshot=await page(tab.id,'snapshot');} catch {}
      await settle(tab.id,run,snapshot).catch(()=>{});
      throw error;
    }
  })().finally(()=>pending.delete(tab.id));
  pending.set(tab.id,control); return control.promise;
}
async function stopAll() {
  const starts=[...pending.values()];
  for(const item of starts) item.cancelled=true;
  await Promise.allSettled(starts.map(item=>item.promise));
  for(const [tabId,run] of Object.entries(await runs())) {
    try {await page(Number(tabId),'stop');await settle(tabId,run,await page(Number(tabId),'snapshot'));} catch {}
  }
}
chrome.runtime.onMessage.addListener((message,sender,reply)=>{
  if(sender.id!==chrome.runtime.id) return;
  // Only extension-owned UI may request account data or auth actions.
  const ownUI=sender.url?.startsWith(chrome.runtime.getURL(''));
  const task=(async()=>{
    if(message?.type==='QQ_ACCOUNT' && ownUI) {
      if(message.action==='redeem') {
        if(typeof message.code!=='string' || message.code.length>100) throw new Error('Enter a valid access code.');
        return {result:await QQAccount.rpc('qq_redeem_code',{p_code:message.code}),account:await QQAccount.status()};
      }
      if(['codes','createCode','revokeCode'].includes(message.action)) {
        const action={codes:'list',createCode:'create',revokeCode:'revoke'}[message.action];
        return {result:await QQAccount.rpc('qq_code_admin',{p_action:action,...(action==='revoke'?{p_id:message.codeId}:{})})};
      }
      if(message.action==='login') return {account:await QQAccount.login()};
      if(message.action==='logout') {await stopAll(); await QQAccount.logout();}
      return {account:await QQAccount.status(),update:await QQUpdates.check()};
    }
    if(message?.type==='QQ_RUN_STATUS') {
      const tab=sender.tab || (ownUI ? (await chrome.tabs.query({active:true,currentWindow:true}))[0] : null);
      if(!validTab(tab)) throw new Error('Open an InQuizitive assignment.');
      return {snapshot:await page(tab.id,'snapshot')};
    }
    if(message?.type!=='QUESTION_HELPER_COMMAND' || !['start','stop'].includes(message.action)) throw new Error('Unknown QuickQuizitive command.');
    const tab=sender.tab || (ownUI ? (await chrome.tabs.query({active:true,currentWindow:true}))[0] : null);
    if(!validTab(tab)) throw new Error('Open QuickQuizitive on an InQuizitive assignment.');
    if(message.action==='start') return start(tab);
    if(pending.has(tab.id)) pending.get(tab.id).cancelled=true;
    const result=await page(tab.id,'stop');
    const run=(await runs())[tab.id];
    if(run) await settle(tab.id,run,await page(tab.id,'snapshot'));
    return {result};
  })();
  task.then(reply).catch(error=>reply({error:error.message}));return true;
});
chrome.action.onClicked.addListener(async tab=>{
  if(!validTab(tab)) return;
  await chrome.scripting.executeScript({target:{tabId:tab.id},files:['floating.js']});
});
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='qq-monitor') monitor();});
chrome.runtime.onInstalled.addListener(()=>chrome.alarms.create('qq-monitor',{periodInMinutes:0.5}));
chrome.runtime.onStartup.addListener(()=>{chrome.alarms.create('qq-monitor',{periodInMinutes:0.5});monitor();});
chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});

setInterval(()=>monitor().catch(()=>{}),5000);
