/* Expanded panel; compact Run/Stop uses the same background authorization path. */
const $ = id => document.getElementById(id);
let busy=false, accountBusy=false, currentAccount=null;
function notice(message='') {$('notice').textContent=message;$('notice').hidden=!message;}
async function send(type,action,extra={}) {
  const response=await chrome.runtime.sendMessage({type,action,...extra});
  if(response?.error) throw new Error(response.error);
  return response;
}
function renderAccount(account) {
  currentAccount=account;
  const unlimited=account.unlimited===true || ['admin','unlimited'].includes(account.plan);
  $('signin').hidden=!account.configured || account.signedIn;
  $('signout').hidden=!account.signedIn;
  $('start').disabled=!account.configured || !account.signedIn || account.allowed===false || busy;
  $('privacy').hidden=Boolean(account.signedIn);
  $('plan').textContent=account.signedIn ? (unlimited ? (account.plan==='admin'?'Admin · Unlimited':'Unlimited access') : `${account.plan==='paid'?'Paid':'Free'} plan`) : 'Your account';
  $('account-copy').textContent=!account.configured ? 'Account setup is not connected yet.' : !account.signedIn ? 'Sign in to get your monthly assignment allowance.' : account.allowed===false ? 'This account is disabled. Contact support.' : unlimited ? '∞ Unlimited assignments' : `${account.remaining} of ${account.limit} assignments remaining`;
  const valid=account.resetAt && Number.isFinite(new Date(account.resetAt).getTime());
  $('reset').hidden=!account.signedIn || !valid;
  if(valid) $('reset').textContent=unlimited ? 'No monthly cap. Unlimited access stays active at the reset.' : `Resets ${new Date(account.resetAt).toLocaleDateString(undefined,{timeZone:'UTC'})} · 00:00 UTC`;
  $('account-details').hidden=!account.signedIn;
  $('account-email').textContent=account.email || '';
  $('used').textContent=String(account.used ?? '—');
  $('allowance').textContent=unlimited?'Unlimited':String(account.limit ?? '—');
  $('access-code').disabled=$('redeem-submit').disabled=accountBusy || unlimited || account.allowed===false;
  $('owner-tools').hidden=account.plan!=='admin' || account.allowed===false;
  if(!account.signedIn){$('generated-code').value='';$('generated-code').hidden=true;$('code-list').replaceChildren();$('access-code').value='';$('account-details').open=false;}
}
async function refresh() {
  try {
    const response=await send('QQ_ACCOUNT','status');
    renderAccount(response.account);
    $('update').hidden=!response.update?.available;
    if(response.update?.available) $('update').textContent=`Version ${response.update.version} is available. Download update ↗`;
  } catch(error) {renderAccount({configured:true,signedIn:false});notice(error.message);$('start').disabled=true;}
}
$('signin').addEventListener('click',async()=>{
  $('signin').disabled=true;notice();
  try {renderAccount((await send('QQ_ACCOUNT','login')).account);} catch(error) {notice(error.message);}
  finally {$('signin').disabled=false;}
});
$('signout').addEventListener('click',async()=>{
  try {await send('QQ_ACCOUNT','logout');await refresh();} catch(error) {notice(error.message);}
});
$('start').addEventListener('click',async()=>{
  if(busy)return;busy=true;$('start').disabled=true;notice();
  try {await send('QUESTION_HELPER_COMMAND','start');} catch(error) {notice(error.message);}
  finally {busy=false;await refresh();}
});
$('stop').addEventListener('click',async()=>{
  try {await send('QUESTION_HELPER_COMMAND','stop');} catch(error) {notice(error.message);}
});
if(window.parent!==window && typeof ResizeObserver!=='undefined') {
  const resize=()=>window.parent.postMessage({type:'QUESTION_HELPER_RESIZE',height:Math.ceil(document.querySelector('.app').getBoundingClientRect().height)},'https://ncia.wwnorton.com');
  new ResizeObserver(resize).observe(document.querySelector('.app'));resize();
}
if(typeof chrome!=='undefined' && chrome.runtime?.id) refresh();
else {renderAccount({configured:false,signedIn:false});notice('Preview only. Load this folder as a Chrome extension to connect your account.');}

window.addEventListener('focus',()=>{if(typeof chrome!=='undefined' && chrome.runtime?.id) refresh();});

function accountMessage(text){$('account-message').textContent=text;}
async function accountAction(fn){if(accountBusy)return;accountBusy=true;for(const id of ['refresh-account','generate-code','refresh-codes','signout'])$(id).disabled=true;renderAccount(currentAccount);try{await fn();}catch(error){accountMessage(error.message);}finally{accountBusy=false;for(const id of ['refresh-account','generate-code','refresh-codes','signout'])$(id).disabled=false;renderAccount(currentAccount);}}
$('refresh-account').addEventListener('click',()=>accountAction(async()=>{await refresh();accountMessage('Account refreshed.');}));
$('redeem-form').addEventListener('submit',event=>{event.preventDefault();const code=$('access-code').value.trim();if(!code)return;accountAction(async()=>{accountMessage('Checking code…');const response=await send('QQ_ACCOUNT','redeem',{code});renderAccount(response.account);const result=response.result;const messages={already_unlimited:'Unlimited access is already active. The code wasn’t used.',try_later:'Too many attempts. Try again in 15 minutes.',account_disabled:'This account is disabled.',invalid_code:'Code invalid, revoked, or already used.'};accountMessage(result.redeemed?'Unlimited access unlocked.':messages[result.reason]||'Unable to redeem this code.');if(result.redeemed)$('access-code').value='';});});
async function loadCodes(){const {result}=await send('QQ_ACCOUNT','codes');$('code-list').replaceChildren();for(const code of result.codes||[]){const li=document.createElement('li'),label=document.createElement('span');label.textContent=`…${code.id.slice(-8)} · ${code.redeemedAt?'Redeemed':code.revoked?'Revoked':'Available'}`;li.append(label);if(!code.redeemedAt&&!code.revoked){const button=document.createElement('button');button.className='text-button';button.textContent='Revoke';button.addEventListener('click',()=>accountAction(async()=>{const response=await send('QQ_ACCOUNT','revokeCode',{codeId:code.id});if($('generated-code').dataset.codeId===code.id){$('generated-code').value='';$('generated-code').hidden=true;}accountMessage(response.result.revoked?'Code revoked.':'Code is already used or revoked.');await loadCodes();}));li.append(button);}$('code-list').append(li);}if(!result.codes?.length)$('code-list').textContent='No codes yet.';}
$('refresh-codes').addEventListener('click',()=>accountAction(loadCodes));
$('generate-code').addEventListener('click',()=>accountAction(async()=>{const {result}=await send('QQ_ACCOUNT','createCode');$('generated-code').value=result.code;$('generated-code').dataset.codeId=result.id;$('generated-code').hidden=false;accountMessage('Code created. Select and copy it to share privately.');await loadCodes();}));

async function refreshCompletion(){if(document.hidden)return;try{const {snapshot}=await send('QQ_RUN_STATUS');$('completion').hidden=!snapshot?.completed;}catch{$('completion').hidden=true;}}
if(typeof chrome!=='undefined' && chrome.runtime?.id){refreshCompletion();setInterval(refreshCompletion,1500);document.addEventListener('visibilitychange',refreshCompletion);}
